Our package includes the following files:

CleanRFWOD.jar
CleanUp.bat
SquashUpdateHTML.jar
MavenGlobalSettings.txt
Readme.txt

Please follow our guide and install them in the referred locations. 

Notes - Squash installers versions used: 

squash-tf-execution-server-2.3.0-RELEASE-win64-installer.jar
squash-tm-1.21.0.RELEASE-installer.jar


Thank you.