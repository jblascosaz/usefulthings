
#coding=utf-8
#########################
###--- pageLOGIN--- ###
#########################

pageLogin_Input_Password = "//input[@id='password']"
pageLogin_Input_UserName = "//input[@id='username']"
pageLogin_Input_Login = "//input[@id='Login']"


#########################
###--- pageWelcome--- ###
#########################
pageWelcome_Link_Accueil = "//a[@title='Accueil']"
pageWelcome_Link_Leads = "//a[@title='Leads']"

#########################
###--- pageLeadsCreation--- ###
#########################
pageLeads_Button_Nouveau = "//a[@title='Nouveau']"
pageLeads_Button_Enregistrer = "//button[@title='Enregistrer']"
pageLeads_Notification_Message = "//div[contains(@class,'genericNotification')]"
pageLeads_Notification_Error = "//ul[contains(@class,'errorsList')]"
pageLeads_Label_Salutation = u"//span[contains(text(), 'Civilité')]"
pageLeads_ListValues_Salutation = u"//span[contains(text(), 'Civilité')]/../../div"
pageLeads_SelectValue_Salutation = "//a[@title='${${lead}.salutation}']"
pageLeads_Input_Name = "//input[@placeholder='Nom de famille']"
pageLeads_Input_FirstName = u"//input[@placeholder='Prénom']"
pageLeads_Input_Street = "//textarea[@placeholder='Rue']"
pageLeads_Input_PostalCode = "//input[@placeholder='Code postal']"
pageLeads_Input_City = "//input[@placeholder='Ville']"
pageLeads_Label_Statutaire = "//span[contains(text(), 'Statutaire')]"
pageLeads_Checkbox_Statutaire = "//span[contains(text(), 'Statutaire')]/../../input"
pageLeads_Label_LeadOrigin = "//span[contains(text(), 'Origine du lead')]/../../div"
pageLeads_ListValues_LeadOrigin = "//span[contains(text(), 'Origine du lead')]/../../div"
pageLeads_SelectValue_LeadOrigin = "//a[@title='${${lead}.leadOrigin}']"
pageLeads_Label_LeadChannel = "//span[contains(text(), 'Canal du lead')]/../../div"
pageLeads_ListValues_LeadChannel = "//span[contains(text(), 'Canal du lead')]/../../div"
pageLeads_SelectValue_LeadChannel = "//a[@title='${${lead}.leadChannel}']"
pageLeads_Input_Email = "//input[@type='email']"
pageLeads_Label_DateOfBirth = "//span[contains(text(), 'Date de naissance')]"
pageLeads_Input_DateOfBirth = "//input[contains(text(), 'Date de naissance')]/../../div/input"
pageLeads_Input_Phone = "//input[@type='tel']"
pageLeads_ListValues_ProductCategory = u"//span[contains(text(), 'Catégorie de Produit')]/../../div/div/div/div"
pageLeads_SelectValue_ProductCategory = u"//a[@title='${${lead}.productCategory}']"
pageLeads_Input_Product = "//input[@title='Recherchez les Produits']"
pageLeads_SelectValue_Product = "//div[@title='${${lead}.product}']"

#########################
###--- pageLeadsQualification--- ###
#########################
pageLeads_Link_LeadName = "//a[@title='${${lead}.firstName} ${${lead}.name}']"
pageLeads_Field_LeadName = "//div[@class='slds-media__body']/h1/div/span"
pageLeads_Field_LeadPhone = u"//span[@title='Téléphone']/../div"
pageLeads_Field_LeadOrigin = "//span[contains(text(), 'Origine du lead')]/../../div[2]/span"
pageLeads_ListBox_Status1 = "//li[1][@role='presentation']/a/span[2]"
pageLeads_ListBox_Status2 = "//li[2][@role='presentation']/a/span[2]"
pageLeads_ListBox_Status3 = "//li[3][@role='presentation']/a/span[2]"
pageLeads_ListBox_Status4 = "//li[4][@role='presentation']/a/span[2]"
pageLeads_ListBox_Status5 = "//li[5][@role='presentation']/a/span[2]"
pageLeads_Button_MarquerEtapeQualificationEnCours = "//span[contains(text(),'Marquer Etape de Qualification en cours')]"

pageLeads_Notification_Message2 = "//div[@class='toastContent slds-notify__content']"
pageLeads_Section_SubHearder = "//div[2][@class='row region-subheader']"
pageLeads_Button_Fermer = "//button[@title='Fermer']"
pageLeads_Button_Modifier = "//a[@class='forceActionLink' and @title='Modifier']"
pageLeads_Button_DateOfBirthModification = "//button[@title='Modifier Date de naissance']"	
pageLeads_Input_DateOfBirthModification = "//a[@class='datePicker-openIcon display']/../input[@type='text']"
pageLeads_Button_ActionEnregistrer = "//span[contains(text(),'Enregistrer')]"
pageLeads_Button_Enregistrer2 = "//div[@class='modal-footer slds-modal__footer']/div/button[@title='Enregistrer']"
pageLeads_Button_MarquerEtapeQualificationTerminee = u"//span[contains(text(),'Marquer Etape de Qualification comme terminé(e)')]"

pageLeads_PopupConvertirLaLead = "//div[@class='modal-container slds-modal__container']/div/h2[contains(text(),'Convertir la lead')]"
pageLeads_Button_PopupConvertirLaLead = "//div[@class='modal-container slds-modal__container']/div/h2[contains(text(),'Convertir la lead')]"
pageLeads_Button_Convertir = "//span[contains(text(),'Convertir')]"
pageLeads_Button_ChoisirExistant1 = "//span[contains(text(),'Choisir existant')][1]"
pageLeads_Button_PopupLeadConvertie = "//span[contains(text(),'Votre lead a été convertie')]"
pageLeads_Button_FermerCetteFenetre = u"//button[@title='Fermer cette fenêtre']"