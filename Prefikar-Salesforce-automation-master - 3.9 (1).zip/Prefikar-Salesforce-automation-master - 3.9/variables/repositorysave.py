#########################
###--- pageLOGIN--- ###
#########################

pageLogin_Input_Password = "//input[@id='password']"
pageLogin_Input_Login = "//input[@id='Login']"


#########################
###--- pageWelcome--- ###
#########################
pageWelcome_Link_Accueil = "//a[@title='Accueil']"
pageWelcome_Link_Leads = "//a[@title='Leads']"

#########################
###--- pageLeads--- ###
#########################
pageLeads_Button_Nouveau = "//a[@title='Nouveau']"
pageLeads_Button_Enregistrer = "//button[@title='Enregistrer']"
pageLeads_Notification_Message = "//div[contains(@class,'genericNotification')]"
pageLeads_Notification_Error = "//ul[contains(@class,'errorsList')]"
#pageLeads_Listbox_Salutation = "//div[@class='uiInput uiInputSelect forceInputPicklist uiInput--default uiInput--select' and contains(text(), 'Civilité')]"
pageLeads_Input_LastName = "//input[@id='lastName compoundBLRadius compoundBRRadius form-element__row input']"
