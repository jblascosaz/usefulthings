##########################
### --- USER CLASS --- ###
##########################

class User:
	def __init__(self, name, password):
		self.name = name
		self.password = password


class Lead:
	def __init__(self, salutation, name, firstName, leadOrigin, leadChannel, phone, dateOfBirth, productCategory, product):
		self.salutation = salutation
		self.name = name
		self.firstName = firstName
		self.leadOrigin = leadOrigin
		self.leadChannel = leadChannel
		self.phone = phone
		self.dateOfBirth = dateOfBirth
		self.productCategory = productCategory
		self.product = product
