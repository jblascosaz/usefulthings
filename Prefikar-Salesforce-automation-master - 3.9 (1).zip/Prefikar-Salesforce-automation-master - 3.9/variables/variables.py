# coding=utf-8
#######################
### --- IMPORTS --- ###
#######################

from base.classes import User
from base.classes import Lead



#########################
###--- ENVIRONMENT--- ###
#########################


url_dev = "https://alpha-scale--uat3.my.salesforce.com/"
url_int = "https://alpha-scale--uat3.my.salesforce.com/"
url_rec = "https://alpha-scale--uat3.my.salesforce.com/"
url_pprod = "https://alpha-scale--uat3.my.salesforce.com/"
url_uat = "https://alpha-scale--uat3.my.salesforce.com/"
url_walkme = "https://eu-account.walkme.com/ExtensionDownload/downloadPage.html?guid=63b93880ec6011ea97b82d28a66f9bbe&customer=axanobilas_enterprise_4qyv&profile=default"
url_uat_reparateur = "https://alpha-scale--uat3.sandbox.my.site.com/PrefikarReparateur/s/"