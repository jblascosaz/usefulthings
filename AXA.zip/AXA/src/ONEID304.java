import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ONEID304 {

	public static WebDriver driver;
	private static String webURL;
	//Atributos login
	private static By username = By.xpath("//input[@placeholder='Username']");
	private static By pass = By.xpath("//input[@placeholder='Password']");
	private static By login = By.xpath("//button[text()]");
	//Atributos 4
	private static By admin = By.xpath("//a[text()='Admin ']");
	private static By IdentifyRepository = By.xpath("//i[@class='svicon2-id-repo']");
	private static By Entitlements = By.xpath("//li[@id='ent']/a");
	private static By inputEntitlements = By.xpath("//input[@id='dtsearch_EntitlementValueList']");
	private static By btEntitlements = By.xpath("//button[@id='search_EntitlementValueList']");
	//Cadena que contiene un Entitlement Value del List
	private static String value = "MTB364";
	private static By EntitlementList = By.xpath("//a[text()='"+value+"']");
	private static By EntitlementType = By.xpath("//a[text()='"+value+"']//following::td[text()='Location_System']");




	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		initDriver("https://axagroup-test.saviyntcloud.com");

		//LOGIN
		login();

		//ONEID304
		ONEID304(value);

	}

	//Metodo para iniciar el navegador
	public static void initDriver(String webURL) {
		System.setProperty("webdriver.chrome.driver", ".\\src\\resources\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		driver = new ChromeDriver(options);
		driver.get(webURL);
	}

	//Metodo login
	public static void login() {
		driver.findElement(username).sendKeys("JBARRAGAN");
		driver.findElement(pass).sendKeys("Citron00*-");
		driver.findElement(login).click();
	}
	//METODOS 4
	public static void ONEID304(String value) throws Exception {
		driver.findElement(admin).click();
		driver.findElement(IdentifyRepository).click();
		Thread.sleep(1000);
		driver.findElement(Entitlements).click();
		driver.findElement(inputEntitlements).sendKeys(value);
		driver.findElement(btEntitlements).click();
		Thread.sleep(1000);
		boolean present; 
		try { 
			driver.findElement(EntitlementList); 
			driver.findElement(EntitlementType);
			present = true;
			System.out.println("El elemento se ha encontrado");
		}
		catch (NoSuchElementException e) { 
			present = false; 
			System.out.println("El elemento no se ha encontrado");
		}





	}



}