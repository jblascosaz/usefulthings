import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ONEID303 {

	public static WebDriver driver;
	private static String webURL;
	//Atributos login
	private static By username = By.xpath("//input[@placeholder='Username']");
	private static By pass = By.xpath("//input[@placeholder='Password']");
	private static By login = By.xpath("//button[text()]");
	//Atributos 3
	private static By admin = By.xpath("//a[text()='Admin ']");
	private static By IdentifyRepository = By.xpath("//i[@class='svicon2-id-repo']");
	private static By Entitlements = By.xpath("//li[@id='ent']/a");
	private static By Advanced = By.xpath("//button[text()=' Advanced ']");
	//private static By SecuritySystem = By.xpath("//select[@id='securitysystems']");
	private static By SecuritySystem = By.xpath("//label[@aria-label='securitysystem1']//following-sibling::div");
	private static By LblSecuritySystem = By.xpath("//div[@id='select2-drop']//input[@aria-label='Search']");
	private static By EndPoints = By.xpath("//label[@aria-label='endpoint1']//following-sibling::div");
	private static By LblEndPoints = By.xpath("//div[@id='select2-drop']//input[@aria-label='Search']");
	private static By EntitlementType = By.xpath("//label[@aria-label='entitlementtype1']//following-sibling::div");
	private static By LblEntitlementType = By.xpath("//input[@id='s2id_autogen4']");
	private static By OrganationSystems = By.xpath("//div[text()='Organisation_System']");
	private static By btSearch = By.xpath("//button[@id='dosearch']");
	private static By btUpdate = By.xpath("//i[@class='icon-circle-arrow-up']//ancestor::a");
	//Cadena que contiene un Entitlement Value del List
	private static String value = "MTB364";
	private static By EntitlementList = By.xpath("//a[text()='"+value+"']");
	private static By Description = By.xpath("(//label[text()='Description']//following::input)[1]");
	//Texto que se modificar� en el description
	private static String textModified = "Ejemplo5";


	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		initDriver("https://axagroup-test.saviyntcloud.com");

		//LOGIN
		login();

		//ONEID303
		ONEID303("AXA Systems","AXA Systems","Location_System");

	}

	//Metodo para iniciar el navegador
	public static void initDriver(String webURL) {
		System.setProperty("webdriver.chrome.driver", ".\\src\\resources\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		driver = new ChromeDriver(options);
		driver.get(webURL);
	}

	//Metodo login
	public static void login() {
		driver.findElement(username).sendKeys("JBARRAGAN");
		driver.findElement(pass).sendKeys("Citron00*-");
		driver.findElement(login).click();
	}
	//METODOS 3
	public static void ONEID303(String ValueSecuritySystems, String ValueEndPoints, String ValueEntitlementType) throws Exception {
		driver.findElement(admin).click();
		driver.findElement(IdentifyRepository).click();
		Thread.sleep(1000);
		driver.findElement(Entitlements).click();
		driver.findElement(Advanced).click();
		Thread.sleep(1500);
		//Seleccion valor SecuritySystem
		driver.findElement(SecuritySystem).click();
		driver.findElement(LblSecuritySystem).sendKeys(ValueSecuritySystems);
		Thread.sleep(1000);
		driver.findElement(LblSecuritySystem).sendKeys(Keys.ENTER);
		//Seleccion valor EndPoint
		driver.findElement(EndPoints).click();
		driver.findElement(LblEndPoints).sendKeys(ValueEndPoints);
		Thread.sleep(1000);
		driver.findElement(LblEndPoints).sendKeys(Keys.ENTER);
		//Seleccion valor EntitlementType
		driver.findElement(EntitlementType).click();
		driver.findElement(LblEntitlementType).sendKeys(ValueEntitlementType);
		Thread.sleep(1000);
		driver.findElement(LblEntitlementType).sendKeys(Keys.ENTER);
		driver.findElement(btSearch).click();
		Thread.sleep(1500);
		driver.findElement(EntitlementList).click();
		Thread.sleep(1000);
		String textDescription = driver.findElement(Description).getAttribute("value");
		driver.findElement(Description).clear();
		driver.findElement(Description).sendKeys(textModified);
		driver.findElement(btUpdate).click();
		Thread.sleep(1500);
		String textDescription2 = driver.findElement(Description).getAttribute("value");
		if (textDescription.equals(textDescription2)) {
			System.out.println("The text has not been modified");
		}else {
			System.out.println("The text has been modified");
		}

	}
	public static WebElement findElement(By locator) throws Exception {
		WebElement element = null;
		try {
			element = getDriver().findElement(locator);
		} catch (Exception e) {
			e.printStackTrace();
			//takeErrorScreenshot(getDriver(), "findElement");
			// getDriver().close(); // getDriver().quit(); if(debug) { throw new Exception(e); } throw new Exception("\nCan't find element "+locator);

		}
		return element;
	}
	public static WebDriver getDriver(){ return driver;}

}