import keyboard as ky


def typing(word):
    return ky.write(word)


def pulse_enter():
    return ky.send('enter')
